"""
    Because GLIM seems to be inaccurate in some parts of Australia and there has been a new map published in 2012 (same
    year as GLIM was published) this script processes the 2012 Australia lithology map into the GLIM classes.
"""

import os
import geopandas as gpd
from collections import Counter
import pandas as pd
from rtree import index
from shapely.geometry import shape, Point
from osgeo import gdal
import os
import rasterio
from rasterio import features
import geopandas as gpd
from shapely.geometry import Polygon
from osgeo import osr
from pyogrio import read_dataframe



#   paths to the input shapefile and to the output
orig_dir = r'g:\_HyGS\_input_data\shapefiles\GeologicUnitPolygons1M_wgs84.shp'
new_dir = r'g:\_HyGS\_input_data\shapefiles\GeologicUnitPolygons1M_GLIM_classes_wgs84.shp'
glim_dir = r'g:\_HyGS\_input_data\shapefiles\_GLIM_australia_clip_wgs84.shp'
md_basin_dir = r'G:\_HyGS\_input_data\shapefiles\_murray_davis_basin_boundary_wgs84.shp'
out_md_dir = r'g:\_HyGS\_input_data\_murray_davis_basin_test'
os.makedirs(out_md_dir, exist_ok = True)

#   load in the existing shapefile with the lithologies and get a list of all the lithology codes
orig_litho_gdf = gpd.read_file(orig_dir)
orig_litho_codes = orig_litho_gdf['PLOTSYMBOL'].unique().tolist()
aus_litho_clip_exploded = orig_litho_gdf.explode()
glim_gdf = gpd.read_file(glim_dir)
glim_clip_exploded = glim_gdf.explode()

#   clip the shapefile to the boundary of the Murray-Davis basin
md_basin_gdf = gpd.read_file(md_basin_dir)

if os.path.isfile(os.path.join(out_md_dir, '_glim_clip.shp')):
    glim_clip = gpd.read_file(os.path.join(out_md_dir, '_glim_clip.shp'))
    glim_clip_exploded = gpd.read_file(os.path.join(out_md_dir, '_glim_clip_exploded.shp'))
else:
    #   export them to shapefiles
    glim_clip = gpd.clip(glim_gdf, md_basin_gdf)
    glim_clip.to_file(os.path.join(out_md_dir, '_glim_clip.shp'), driver='ESRI Shapefile')
    glim_clip_exploded = glim_clip.explode()
    glim_clip_exploded.to_file(os.path.join(out_md_dir, '_glim_clip_exploded.shp'), driver='ESRI Shapefile')

if os.path.isfile(os.path.join(out_md_dir, '_AUS_litho_clip.shp')):
    #aus_litho_clip = gpd.read_file(os.path.join(out_md_dir, '_AUS_litho_clip.shp'))
    aus_litho_clip_exploded = gpd.read_file(os.path.join(out_md_dir, '_AUS_litho_clip_exploded.shp'))
else:
    aus_litho_clip = gpd.clip(orig_litho_gdf, md_basin_gdf)
    aus_litho_clip.to_file(os.path.join(out_md_dir, '_AUS_litho_clip.shp'), driver='ESRI Shapefile')
    aus_litho_clip_exploded = aus_litho_clip.explode()
    aus_litho_clip_exploded.to_file(os.path.join(out_md_dir, '_AUS_litho_clip_exploded.shp'), driver='ESRI Shapefile')

#   create a copy of the geodataframe
glim_clip_exploded_sample_pts_gdf = glim_clip_exploded.copy()
#   change the geometry field to a point
glim_clip_exploded_sample_pts_gdf['geometry'] = glim_clip_exploded_sample_pts_gdf.sample_points(size = 1)
#   save as shapefile so we can visualize it in QGIS
glim_clip_exploded_sample_pts_gdf.to_file(os.path.join(out_md_dir, '_glim_sample_points_AUSTRALIA.shp'), driver='ESRI Shapefile')

#   intersect the points with the GLIM dataframe
join_gdf = gpd.sjoin(glim_clip_exploded_sample_pts_gdf, aus_litho_clip_exploded, how = 'left', predicate = 'intersects')
#   change the geometry back to the polygon
join_gdf.loc[list(set(join_gdf.index).intersection(glim_clip_exploded.index)), "geometry"] = glim_clip_exploded["geometry"]
#   drop unnecessary columns to save some space
join_gdf = join_gdf.drop(columns = ['OBJECTID_left', 'STRATNO', 'NAME', 'TYPENAME', 'TYPE_URI', 'GEOLHIST', 'REPAGE_URI',
                                    'YNGAGE_URI', 'OLDAGE_URI', 'LITHOLOGY', 'REPLTH_URI', 'MORPHOLOGY', 'OBSMETHOD',
                                    'CONFIDENCE', 'SOURCE', 'METADATA', 'FRAME', 'RESSCALE', 'CAPTDATE', 'MODDATE',
                                    'PLOTRANK', 'FEATUREID', 'GEOLUNITID', 'SHAPE_LENG', 'SHAPE_AREA', 'Shape_Leng',
                                    'Shape_Area', 'IDENTITY_', 'index_right0', 'index_right1', 'GEODB_OID', 'OBJECTID_right'])
join_gdf = join_gdf.dropna(subset = ['PLOTSYMBOL'])
join_gdf.to_file(os.path.join(out_md_dir, '_join_AUSTRALIA.shp'), driver = 'ESRI Shapefile')

#      loop through the lithological values and get the most frequent class and its value
class_xx_lst, freq_lst = [], []
overall_lst = []
litho_lst = join_gdf['PLOTSYMBOL'].unique().tolist()
for litho in litho_lst:
    #  select the rows
    sel_rows = join_gdf.loc[join_gdf['PLOTSYMBOL'] == litho]
    litho_sel_lst = sel_rows['xx'].values.tolist()
    counts = Counter(litho_sel_lst)
    max_count = counts.most_common(3)
    lithos_lst = [i[0] for i in max_count]
    count_lst = [i[1] for i in max_count]
    class_xx_lst.append(lithos_lst)
    freq_lst.append(count_lst)
    print(litho, lithos_lst, count_lst)
    overall_lst.append([litho, lithos_lst, count_lst])

#   make sure there is no nan class
overall_lst = [i for i in overall_lst if type(i[0]) is not float]

#   count how many times an individual description is found in the GLIM lithological dataset
glim_classes_unique_lst = sorted(list({x for l in class_xx_lst for x in l}))

join_gdf_unique = join_gdf.groupby(['PLOTSYMBOL', 'DESCR', 'xx']).size().reset_index().rename(columns = {0 : 'count'})
join_gdf_unique = join_gdf_unique.sort_values(by = ['PLOTSYMBOL'])
join_gdf_unique.to_csv(os.path.join(out_md_dir, '_AUS_litho_translation_key.csv'))

join_gdf_glim_counts = join_gdf_unique.copy()
join_gdf_glim_counts = join_gdf_glim_counts.drop(columns = ['xx', 'count'])
join_gdf_glim_counts = join_gdf_glim_counts.reindex(columns = join_gdf.columns.values.tolist() + glim_classes_unique_lst)
desc_unique_lst = join_gdf_unique.DESCR.unique().tolist()
#   loop through the unique descriptions and check the xx codes and count - then insert it into the other dataframe
for unique_desc in desc_unique_lst:
    select_rows = join_gdf_unique.loc[join_gdf_unique['DESCR'] == unique_desc]
    for index, row in select_rows.iterrows():
        join_gdf_glim_counts.loc[join_gdf_glim_counts['DESCR'] == unique_desc, row['xx']] = int(row['count'])

join_gdf_glim_counts = join_gdf_glim_counts.drop_duplicates()
join_gdf_glim_counts = join_gdf_glim_counts.sort_values(by = ['PLOTSYMBOL'])
join_gdf_glim_counts.to_csv(os.path.join(out_md_dir, '_AUS_litho_translation_key_description_counts.csv'))

#   select the Quaternary classes
qt_gdf = join_gdf.copy()
qt_gdf['str_class'] = qt_gdf['PLOTSYMBOL'].astype(str).str[0]
qt_gdf = qt_gdf.loc[qt_gdf['str_class'] == 'Q']

qt_qb_gdf = qt_gdf.loc[qt_gdf['PLOTSYMBOL'] == 'Qb']
qt_qb_gdf_unique = qt_qb_gdf.groupby(['PLOTSYMBOL','DESCR', 'xx']).size().reset_index().rename(columns = {0 : 'count'})

qt_gdf = qt_gdf.loc[join_gdf['xx'] != 'su']
qt_gdf.to_file(os.path.join(out_md_dir, '_Q_classes_gdf.shp'), driver = 'ESRI Shapefile')
qt_gdf = qt_gdf.drop(columns = ['geometry', 'Litho', 'MAPSYMBOL'])
qt_gdf = qt_gdf.sort_values(by = ['PLOTSYMBOL'])
qt_gdf.to_csv(os.path.join(out_md_dir, '_Q_classes_gdf.csv'))

#   group by the columns
qt_gdf_unique = qt_gdf.groupby(['PLOTSYMBOL','DESCR', 'xx']).size().reset_index().rename(columns = {0 : 'count'})
qt_gdf_unique.to_csv(os.path.join(out_md_dir, '_Q_classes_gdf_unique.csv'))

#   make the final classification file where we assign a GLIM class to each description field
in_gdf = gpd.read_file(r'g:\_HyGS\_input_data\_murray_davis_basin_test\_AUS_litho_translation_key_description_counts.csv')
sel_columns = ['ev', 'mt', 'pa', 'pb', 'pi', 'py', 'sc', 'sm', 'ss', 'su','va', 'vb', 'vi', 'wb']
col_names = ['description', 'aus_lith0o_code', 'glim_xx_code']
#   make new list with the translator - description, AUS litho class and GLIM class
new_lst, manual_lst = [], []
sel_rows = in_gdf[sel_columns]
for index, row in sel_rows.iterrows():
    if len([i for i in row.values if i != '']) == 1:
        count_val = [i for i in row.values if i != ''][0]
        xx_val = sel_columns[row.values.tolist().index(count_val)]
        new_lst.append([in_gdf.iloc[index]['DESCR'], in_gdf.iloc[index]['PLOTSYMBOL'], xx_val])
    else:
        manual_lst.append(in_gdf.iloc[index])
#   export to csv file
out_df = pd.DataFrame(new_lst, columns = col_names)
out_df.to_csv(os.path.join(out_md_dir, '_aus_classification.csv'))
manual_df = pd.DataFrame(manual_lst, columns = in_gdf.columns.tolist())
manual_df.to_csv(os.path.join(out_md_dir, '_aus_classification_todo.csv'))


#   load the classification key and reclassify the Australia lithology shapefile to the new classes (as well as int code)
litho_class_styles = {'su': {'lith' : 'su', 'lith_full' : 'unconsolidated sediments', 'lith_num' : 100, 'hatch': '', 'color':'gold'},
                      'su_ad': {'lith' : 'su_ad', 'lith_full' : 'alluvial deposits', 'lith_num' : 101, 'hatch':'-.', 'color':'#ffd757'},
                      'su_ds': {'lith' : 'su_ds', 'lith_full' : 'dune sands', 'lith_num' : 102, 'hatch':'-.', 'color':'#fcc100'},
                      'su_lo': {'lith' : 'su_lo', 'lith_full' : 'loess', 'lith_num' : 103, 'hatch':'-.', 'color':'#8a6a00'},
                      'su_mx': {'lith' : 'su_mx', 'lith_full' : 'sand - mixed grain size', 'lith_num' : 104, 'hatch':'O', 'color':'#ffd95f'},
                      'su_ss': {'lith' : 'su_ss', 'lith_full' : 'sand - coarse grained', 'lith_num' : 105, 'hatch':'o', 'color':'#ffd95f'},
                      'su_sh': {'lith' : 'su_sh', 'lith_full' : 'sand - fine grained', 'lith_num' : 106, 'hatch':'.', 'color':'#ffd95f'},
                      'su_cl': {'lith' : 'su_cl', 'lith_full' : 'clay', 'lith_num' : 107, 'hatch':'.', 'color':'grey'},
                      'su_gr': {'lith' : 'su_gr', 'lith_full' : 'gravel', 'lith_num' : 108, 'hatch':'o', 'color':'olivedrab'},
                      'su_sl': {'lith' : 'su_sl', 'lith_full' : 'silt', 'lith_num' : 109, 'hatch':'..', 'color':'lawngreen'},
                      'ss': {'lith' : 'ss', 'lith_full' : 'siliclastic sedimentary rocks', 'lith_num' : 200, 'hatch':'o-', 'color':'forestgreen'},
                      'sm': {'lith' : 'sm', 'lith_full' : 'mixed sedimentary rocks', 'lith_num' : 210, 'hatch':'o-', 'color':'turquoise'},
                      'sc': {'lith' : 'sc', 'lith_full' : 'carbonate sedimentary rocks', 'lith_num' : 220, 'hatch':'o-', 'color':'aqua'},
                      'vb': {'lith' : 'vb', 'lith_full' : 'basic volcanic rocks', 'lith_num' : 300, 'hatch':'o', 'color':'darkorange'},
                      'vi': {'lith' : 'vi', 'lith_full' : 'intermediate volcanic rocks', 'lith_num' : 310, 'hatch':'O', 'color':'darkorange'},
                      'va': {'lith' : 'va', 'lith_full' : 'acid volcanic rocks', 'lith_num' : 320, 'hatch':'oo', 'color':'darkorange'},
                      'pb': {'lith' : 'pb', 'lith_full' : 'basic plutonic rocks', 'lith_num' : 400, 'hatch':'o', 'color':'fuchsia'},
                      'pi': {'lith' : 'pi', 'lith_full' : 'intermediate plutonic rocks', 'lith_num' : 410, 'hatch':'O', 'color':'fuchsia'},
                      'pa': {'lith' : 'pa', 'lith_full' : 'acid plutonic rocks', 'lith_num' : 420, 'hatch':'oo', 'color':'fuchsia'},
                      'mt': {'lith' : 'mt', 'lith_full' : 'metamorphic rocks', 'lith_num' : 500, 'hatch':'-|', 'color':'plum'},
                      'py': {'lith' : 'py', 'lith_full' : 'pyroclastics', 'lith_num' : 600, 'hatch':'x', 'color':'crimson'},
                      'ev': {'lith' : 'ev', 'lith_full' : 'evaporites', 'lith_num' : 700, 'hatch':'o', 'color':'darkorchid'},
                      'rock': {'lith' : 'rock', 'lith_full' : 'rocks', 'lith_num' : 800, 'hatch':'++', 'color':'dimgrey'},
                      'soil': {'lith' : 'soil', 'lith_full' : 'soil', 'lith_num' : 900, 'hatch' : 'o', 'color':'tan'},
                      'coal': {'lith' : 'coal', 'lith_full' : 'coal', 'lith_num' : 1000, 'hatch':'-|', 'color':'black'},
                      'nd': {'lith' : 'nd', 'lith_full' : 'not defined', 'lith_num' : 0, 'hatch':'x', 'color':'snow'}}

key_df = pd.read_csv(r'g:\_HyGS\_input_data\_murray_davis_basin_test\_AUS_litho_to_GLIM_key_v2.csv', delimiter = ';')

#   create a copy of the original lithology file and drop unnecessary columns
out_df = orig_litho_gdf.copy().drop(columns = ['MAPSYMBOL','STRATNO', 'NAME', 'TYPENAME', 'TYPE_URI', 'GEOLHIST',
                                               'REPAGE_URI', 'YNGAGE_URI','OLDAGE_URI', 'LITHOLOGY', 'REPLTH_URI',
                                               'MORPHOLOGY', 'OBSMETHOD', 'CONFIDENCE', 'SOURCE', 'METADATA', 'FRAME',
                                               'RESSCALE', 'CAPTDATE', 'MODDATE', 'PLOTRANK', 'FEATUREID', 'GEOLUNITID'])
del orig_litho_gdf

#   add new columns where we will store the GLIM classes
out_df['xx'] = ''
out_df['glim_num'] = 0

#   go through the rows and find the corresponding code from the key_df
for index, row in out_df.iterrows():
    try:
        glim_xx = key_df.loc[key_df['description'] == row['DESCR'], 'glim_xx_code'].values[0]
        glim_num = litho_class_styles.get(glim_xx)['lith_num']
        out_df.at[index, 'xx'] = glim_xx
        out_df.at[index, 'glim_num'] = glim_num
    except IndexError:
        pass
    if index % 1000 == 0:
        print(index)

out_df.to_file(os.path.join(out_md_dir, '_GLIM_2_v3_AUS.shp'), driver = 'ESRI Shapefile')


#   Function to clip a shapefile feature (e.g. river, coastline), rasterize and then create a raster grid with distance
#   in km to the original shapefile feature.
"""
in_shp = os.path.join(out_md_dir, '_GLIM_2_v3_AUS.shp')
in_raster = r'g:\_HyGS\_input_data\_ML_input_data\_glim.tif'
in_raster = r'g:\_HyGS\_input_data\_ML_input_data\_glim_2.tif'
out_clip_shp_dir = os.path.join(out_md_dir, '_GLIM_2_v3_AUS_clip.shp')
out_clip_raster_dir = os.path.join(out_md_dir, '_GLIM_2_v3_AUS_clip.tif')
out_distance_dir = os.path.join(out_md_dir, '_GLIM_2_v3_AUS.tif')
attribute_colname = 'glim_num'
"""
def clip_rasterize_and_distance(in_shp, in_raster, out_clip_shp_dir, out_clip_raster_dir, attribute_colname):
    #   read in the raster and its geometry definition
    with rasterio.open(in_raster) as src:
        band = src.read()
        affine = src.transform
        meta = src.meta.copy()
        meta.update(compress='lzw')
    #   create a bounding box for clipping
    ymin, xmin = affine[5] - band.shape[1] * affine[0], affine[2]
    ymax, xmax = affine[5], affine[2] + band.shape[2] * affine[0]
    #   now clip the input shapefile to match the bounding box
    #shp = gpd.read_file(in_shp)
    shp = read_dataframe(in_shp)
    #   define the bounding box and clip the shapefile
    bbox = Polygon([(xmin, ymin), (xmin, ymax), (xmax, ymax), (xmax, ymin), (xmin, ymin)])
    clipped_shp = gpd.clip(shp, bbox)
    # save clipped shapefile
    clipped_shp.to_file(out_clip_shp_dir, driver = "ESRI Shapefile")
    del shp
    #   now rasterize the clipped shapefile
    with rasterio.open(out_clip_raster_dir, 'w+', **meta) as out:
        out_arr = out.read(1)
        # this is where we create a generator of geom, value pairs to use in rasterizing
        #clipped_shp[attribute_colname] = 0
        shapes = ((geom, value) for geom, value in zip(clipped_shp.geometry, clipped_shp[attribute_colname]))
        burned = features.rasterize(shapes = shapes, fill = 0, out = out_arr, transform = out.transform)
        out.write_band(1, burned)












for gt_class in qt_classes:
    join_gdf.loc[(join_gdf[] ==) & (join_gdf[] == )]['DESCR'].values






join_gdf_group = gpd.overlay(aus_litho_clip_exploded.centroid, glim_clip_exploded, how = 'intersection')




test_glim_gdf = gpd.read_file(r'g:\_HyGS\_input_data\_murray_davis_basin_test\_glim_clip_TEST.shp')
test_aus_litho_gdf = gpd.read_file(r'g:\_HyGS\_input_data\_murray_davis_basin_test\_AUS_litho_clip_TEST_2.shp')

aus_litho_clip_index = test_aus_litho_gdf.sindex

test_aus_litho_gdf.set_crs(epsg = 4326)
test_glim_gdf.set_crs(epsg = 4326, inplace=True)

for index, row in test_glim_gdf.iterrows():
    possible_matches_index = list(aus_litho_clip_index.query(row.geometry))
    possible_matches = test_aus_litho_gdf.iloc[possible_matches_index]
    # run true intersection query only on possible matches
    actual_matches = gpd.overlay(possible_matches, test_glim_gdf)
    actual_matches = possible_matches[possible_matches.overlay(row.geometry)]
    print(len(actual_matches))



#   make a spatial join between the rock gdf and the glim gdf
join_gdf = gpd.sjoin_nearest(test_aus_litho_gdf, test_glim_gdf, how = "left")
join_gdf = gpd.sjoin(test_aus_litho_gdf, test_glim_gdf, how = "left", predicate = 'covers')

join_gdf_group = join_gdf.dissolve(by = 'level_0_left')


join_gdf_group = gpd.overlay(test_aus_litho_gdf, test_glim_gdf)
join_gdf_group.to_file(os.path.join(out_md_dir, '_test.shp'), driver='ESRI Shapefile')


join_gdf = gpd.sjoin(aus_litho_clip_exploded, glim_clip_exploded, how = "left", predicate = 'overlaps')
actual_matches.to_file(os.path.join(out_md_dir, '_test.shp'), driver='ESRI Shapefile')


aus_litho_clip_index = aus_litho_clip.sindex
aus_litho_clip.set_crs(epsg = 4326)
glim_clip.set_crs(epsg = 4326)

for index, row in glim_clip.head(10).iterrows():
    possible_matches_index = list(aus_litho_clip_index.query(row.geometry))
    possible_matches = aus_litho_clip.iloc[possible_matches_index]
    # run true intersection query only on possible matches
    actual_matches = possible_matches[possible_matches.intersects(row.geometry)]
    print(len(actual_matches))



data = []
for index, glim in glim_clip.iterrows():
    for index2, aus_litho in aus_litho_clip.iterrows():
       if glim['geometry'].intersects(aus_litho['geometry']):
          data.append({'geometry': glim['geometry'].intersection(aus_litho['geometry']),
                       'glim_class_xx': glim['xx'],
                       'aus_litho_class': aus_litho['PLOTSYMBOL']})

df = gpd.GeoDataFrame(data,columns=['geometry', 'glim_class_xx', 'aus_litho_class'])
df.to_file('intersection.shp')

# control of the results in mi case, first values
df.head() # image from a Jupiter/IPython notebook



overlay_gdf = gpd.overlay(glim_clip, aus_litho_clip, how = 'union')


join_nearest_gdf = gpd.sjoin_nearest(aus_litho_clip, glim_clip)



#   make a spatial join between the rock gdf and the glim gdf
join_gdf = gpd.sjoin(aus_litho_clip, glim_clip, how = "left", predicate = 'within')

join_gdf = join_gdf.drop(columns = ['OBJECTID_left', 'STRATNO', 'NAME', 'TYPENAME', 'TYPE_URI', 'GEOLHIST', 'REPAGE_URI',
       'YNGAGE_URI', 'OLDAGE_URI', 'LITHOLOGY', 'REPLTH_URI', 'MORPHOLOGY',
       'OBSMETHOD', 'CONFIDENCE', 'SOURCE', 'METADATA', 'FRAME', 'RESSCALE',
       'CAPTDATE', 'MODDATE', 'PLOTRANK', 'FEATUREID', 'GEOLUNITID',
       'SHAPE_LENG', 'SHAPE_AREA', 'index_right', 'Shape_Leng', 'Shape_Area'])

#      loop through the lithological values and get the most frequent class and its value
class_xx_lst, freq_lst = [], []
litho_lst = join_gdf['PLOTSYMBOL'].unique().tolist()
for litho in litho_lst:
    #  select the rows
    sel_rows = join_gdf.loc[join_gdf['PLOTSYMBOL'] == litho]
    litho_sel_lst = sel_rows['xx'].values.tolist()
    counts = Counter(litho_sel_lst)
    max_count = counts.most_common(3)
    lithos_lst = [i[0] for i in max_count]
    count_lst = [i[1] for i in max_count]
    class_xx_lst.append(lithos_lst)
    freq_lst.append(count_lst)
    print(litho, lithos_lst, count_lst)

















#   define the dictionary with the old and new classes
su_classes = ['Qa', 'Qd', 'Qe', 'Qrc', 'Qrl', 'Qs', 'Qt', 'Cza', 'Cze', 'Czk', 'Czl', 'Czq', 'Czrb', 'Czs', 'Czu']
orig_litho_codes = list(set(orig_litho_codes) - set(su_classes))

#   sedimentary rocks are defined as
#       - mudstone, siltstone, sandstone, conglomerate (s)
#       - limestone (l)
#       - coal measures and graphitic sediments (o)
#       - volcanogenic sediments (j)
#       - mixed sediments and volcanic rocks (w)
#       - chemical sediments (c)
ss_classes = [i for i in orig_litho_codes if 's' in i or 'Czc' in i]
orig_litho_codes = list(set(orig_litho_codes) - set(su_classes))
sc_classes = [i for i in orig_litho_codes if 'l' in i]
orig_litho_codes = list(set(orig_litho_codes) - set(su_classes))
coal_classes = [i for i in orig_litho_codes if 'o' in i]
orig_litho_codes = list(set(orig_litho_codes) - set(su_classes))
sm_classes = [i for i in orig_litho_codes if 'j' in i or 'w' in i or 'c' in i]
orig_litho_codes = list(set(orig_litho_codes) - set(su_classes))

#   remove rows from the original lithology where the codes match the su or sedimentary rock classes
rock_gdf = orig_litho_gdf[orig_litho_gdf['PLOTSYMBOL'].isin(orig_litho_codes)]

#   make a spatial join between the rock gdf and the glim gdf
join_gdf = gpd.sjoin(rock_gdf, glim_gdf, how = "inner", op = 'intersects')

join_gdf = join_gdf.drop(columns = ['OBJECTID_left', 'STRATNO', 'NAME', 'TYPENAME', 'TYPE_URI', 'GEOLHIST', 'REPAGE_URI',
       'YNGAGE_URI', 'OLDAGE_URI', 'LITHOLOGY', 'REPLTH_URI', 'MORPHOLOGY',
       'OBSMETHOD', 'CONFIDENCE', 'SOURCE', 'METADATA', 'FRAME', 'RESSCALE',
       'CAPTDATE', 'MODDATE', 'PLOTRANK', 'FEATUREID', 'GEOLUNITID',
       'SHAPE_LENG', 'SHAPE_AREA', 'index_right', 'Shape_Leng', 'Shape_Area'])

#      loop through the lithological values and get the most frequent class and its value
class_xx_lst, freq_lst = [], []
litho_lst = join_gdf['PLOTSYMBOL'].unique().tolist()
for litho in litho_lst:
    #  select the rows
    sel_rows = join_gdf.loc[join_gdf['PLOTSYMBOL'] == litho]
    litho_sel_lst = sel_rows['xx'].values.tolist()
    counts = Counter(litho_sel_lst)
    max_count = counts.most_common(3)
    lithos_lst = [i[0] for i in max_count]
    count_lst = [i[1] for i in max_count]
    class_xx_lst.append(lithos_lst)
    freq_lst.append(count_lst)
    print(litho, lithos_lst, count_lst)



join_gdf.to_file(new_dir, driver='ESRI Shapefile')



for key, item in join_gdf.groupby(['PLOTSYMBOL','xx']):
    print(join_gdf.groupby(['PLOTSYMBOL','xx']).get_group(key), "\n\n")


py	Pyroclastics
ev	Evaporites
va	Acid volcanic rocks
vi	Intermediate volcanic rocks
vb	Basic volcanic rocks
pa	Acid plutonic rocks
pi	Intermediate plutonic rocks
pb	Basic plutonic rocks
mt	Metamorphics



['Ns', 'Qrc', 'Qa', 'Ls', 'JKs', 'Czl', 'Cg', 'Czs', 'Qd', 'Ag',
       'Os', 'Ps', 'Lg', 'Mg', 'Ms', 'Js', 'Ab', 'SDs', 'Mc', 'As', 'Av',
       'Czk', 'Ld', 'Ay', 'Mf', 'Pb', 'Sg', 'Ds', 'Czc', 'Aj', 'Ks',
       'Cza', 'Qt', 'Qe', 'SDg', 'Af', 'At', 'Mn', 'Pd', 'Ln', 'Ac', 'Lb',
       'Cs', 'Pw', 'Cw', 'Pg', 'Mt', 'SDw', 'Czrb', 'Dg', 'Cf', 'Es',
       'El', 'Ef', 'EOs', 'Ew', 'Eb', 'Ey', 'Md', 'Pf', 'Ny', 'Ml', 'Lc',
       'Lx', 'An', 'Lf', 'Ly', 'Aw', 'Kg', 'Ss', 'Czz', 'DCy', 'Qs',
       'Czf', 'Qi', 'Eg', 'MEd', 'EOl', 'Ec', 'Czb', '-Pl', 'En', 'Czi',
       'Dw', '-Pd', 'CPs', 'Ad', 'Se', 'Jd', 'Ol', 'Al', 'Dl', 'Ax', 'Og',
       'OSn', 'OSy', 'DCw', 'Dd', 'Ob', 'Jo', 'Cl', 'Mb', 'Dj', 'Ca',
       'Pzz', '-Ps', 'Ll', 'Po', 'Qb', 'Kf', 'Oy', 'Czd', 'Au', 'Ow',
       'Czo', 'Pzs', 'Cy', 'Mv', 'DCs', 'Mzd', 'Sf', 'Le', 'Oj', 'Lw',
       'Ar', 'Cv', 'Lj', 'ODs', 'Nl', 'Cj', 'Lu', 'Dy', 'Dn', 'Df', 'Sw',
       'OSs', 'Mw', 'Ae', 'SDf', 'Czw', 'Pa', 'Lt', 'Czg', 'Czx', 'My',
       'Kl', 'Nz', 'Co', 'Sy', '-Pz', 'Kb', 'Pl', 'Oa', 'Mj', 'CPg', 'St',
       'Qrl', 'Lm', 'Nb', 'CPd', 'Ed', 'Ot', 'Db', 'unk', 'Jw', 'NEd',
       'La', 'PKd', 'Jg', 'DCe', 'Sd', 'Dh', 'Lr', 'Mza', 'Aa', 'EOw',
       'Rg', 'Nn', 'Az', 'Jb', 'Ka', 'Jk', 'EPe', 'Eu', 'Ea', 'Mzs',
       'Cze', 'Ne', 'Pzt', 'Czq', 'Px', 'Of', 'Lz', 'Ja', 'Ng', 'Mx',
       'Pzg', 'Rs', 'Nt', '-Pq', 'Mz', 'Ko', 'RJs', 'Sj', 'Pzd', 'Ou',
       'Cd', 'SDd', 'Jf', 'DCl', 'Cn', 'EOg', 'Sl', 'Su', 'Ra', 'Rf',
       'SDy', 'RJb', 'PRg', 'EPg', 'Ez', 'Oc', 'EPx', 'EOy', 'Oe', 'Kd',
       'DCo', '-Pn', 'Nc', '-Pg', 'Am', 'Qv', 'Nf', 'MNn', 'Ah', 'Lo',
       'PRs', 'Ee', 'Nd', 'Py', 'Od', 'CPx', 'Dt', 'Et', 'CPu', 'Cx',
       'Da', 'SDz', 'Jx', 'Mzg', 'Nw', 'Nk', 'Czu', 'Dc', 'PKw', 'Sb',
       'Ry', 'Rb', 'Er', 'Mq', 'Rd', 'RJo', 'Ro', 'Rv', 'Rw', 'Rj', 'PRf',
       'RJa', 'Me', 'OSg', 'Nx', 'Mk', 'Mzb', '-Pe', 'On', 'Mu', 'Na',
       'Dz', 'Ma', 'NEs', 'Lv', 'CPt', 'Dv', 'Nu', 'Pv', 'Sh', 'EPd',
       'Pze', 'Pe', 'Sa', 'Pzn', 'Pj', 'DCt']

litho_to_glim_dict = {}







